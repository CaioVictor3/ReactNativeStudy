import {
  FlatList,
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { styles } from './styles';
import { useState } from 'react';
import { Orcamento } from '@/types/Orcamento';
import { StatusFilter } from '@/types/FilterStatus';
import { OrcamentoCard } from '@/components/OrcamentoCard';
import { Filter } from '@/components/Filter';
import { Search, SlidersHorizontal } from 'lucide-react-native';

const STATUS_FILTERS: StatusFilter[] = ['Todos', 'Rascunho', 'Enviado', 'Aprovado', 'Recusado'];

const MOCK_ORCAMENTOS: Orcamento[] = [
  {
    id: '1',
    titulo: 'Desenvolvimento de aplicativo de loja online',
    cliente: 'Soluções Tecnológicas Beta',
    itens: [{ id: '1a', descricao: 'Desenvolvimento mobile', quantidade: 1, precoUnitario: 22300 }],
    percentualDesconto: undefined,
    status: 'Aprovado',
    dataCriacao: new Date('2024-01-10').toISOString(),
    dataAtualizacao: new Date('2024-01-15').toISOString(),
  },
  {
    id: '2',
    titulo: 'Consultoria em marketing digital',
    cliente: 'Marketing Wizards',
    itens: [{ id: '2a', descricao: 'Consultoria mensal', quantidade: 2, precoUnitario: 2000 }],
    percentualDesconto: undefined,
    status: 'Rascunho',
    dataCriacao: new Date('2024-01-12').toISOString(),
    dataAtualizacao: new Date('2024-01-12').toISOString(),
  },
  {
    id: '3',
    titulo: 'Serviços de SEO',
    cliente: 'SEO Masters',
    itens: [{ id: '3a', descricao: 'Otimização SEO', quantidade: 1, precoUnitario: 3500 }],
    percentualDesconto: undefined,
    status: 'Enviado',
    dataCriacao: new Date('2024-01-14').toISOString(),
    dataAtualizacao: new Date('2024-01-16').toISOString(),
  },
  {
    id: '4',
    titulo: 'Criação de conteúdo',
    cliente: 'Content Creators',
    itens: [{ id: '4a', descricao: 'Produção de conteúdo', quantidade: 5, precoUnitario: 500 }],
    percentualDesconto: undefined,
    status: 'Rascunho',
    dataCriacao: new Date('2024-01-08').toISOString(),
    dataAtualizacao: new Date('2024-01-08').toISOString(),
  },
  {
    id: '5',
    titulo: 'Gestão de redes sociais',
    cliente: 'Social Experts',
    itens: [{ id: '5a', descricao: 'Gerenciamento mensal', quantidade: 1, precoUnitario: 1800 }],
    percentualDesconto: undefined,
    status: 'Recusado',
    dataCriacao: new Date('2024-01-05').toISOString(),
    dataAtualizacao: new Date('2024-01-07').toISOString(),
  },
  {
    id: '6',
    titulo: 'Design de interface',
    cliente: 'UI/UX Designers',
    itens: [{ id: '6a', descricao: 'Design UI/UX', quantidade: 1, precoUnitario: 5200 }],
    percentualDesconto: undefined,
    status: 'Aprovado',
    dataCriacao: new Date('2024-01-18').toISOString(),
    dataAtualizacao: new Date('2024-01-20').toISOString(),
  },
];

export default function Home() {
  const [orcamentos, setOrcamentos] = useState<Orcamento[]>(MOCK_ORCAMENTOS);
  const [busca, setBusca] = useState('');

  const quantidadeRascunho = orcamentos.filter(o => o.status === 'Rascunho').length;

  return (
    <View style={styles.safeArea}>

      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Orçamentos</Text>
          <Text style={styles.headerSubtitle}>
            Você tem {quantidadeRascunho} item{quantidadeRascunho !== 1 ? 's' : ''} em rascunho
          </Text>
        </View>
        <TouchableOpacity style={styles.novoButton}>
          <Text style={styles.novoButtonText}>+ Novo</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.searchRow}>
        <View style={styles.searchContainer}>
          <Search size={18} color="#888888" />
          <TextInput
            style={styles.searchInput}
            placeholder="Título ou cliente"
            placeholderTextColor="#aaaaaa"
            value={busca}
            onChangeText={setBusca}
          />
        </View>
        <TouchableOpacity style={styles.sortButton}>
          <SlidersHorizontal size={20} color="#444444" />
        </TouchableOpacity>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.filtersScrollView}
        contentContainerStyle={styles.filtersScroll}
      >
        {STATUS_FILTERS.map(status => (
          <Filter
            key={status}
            status={status}
            isActive={'Todos' === status}
          />
        ))}
      </ScrollView>

      <FlatList
        data={orcamentos}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <Text style={styles.emptyText}>Nenhum orçamento encontrado.</Text>
        }
        renderItem={({ item }) => (
          <OrcamentoCard
            orcamento={item}
          />
        )}
      />
    </View>
  );
}

